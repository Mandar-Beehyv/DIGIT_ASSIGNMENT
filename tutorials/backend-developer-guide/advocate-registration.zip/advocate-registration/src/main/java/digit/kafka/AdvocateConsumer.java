package digit.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import digit.repository.AdvocateRepository;
import digit.web.models.AdvocateRequest;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class AdvocateConsumer {

}
